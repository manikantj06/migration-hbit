const express = require("express");

const app = express();

// app.get("/", (req, res) => {
//   res.send(`Hello ${req.params.name}`);
// });

app.use(express.json());
/*

function auth(token){
    
    return {
        next()
    }
    // return false
    res.send()
}

*/

app.post("/books", auth, (req, res) => {
  console.log(req.body);
  res.send("Hello post");
});

app.listen(8000, () => {
  console.log("server started");
});
