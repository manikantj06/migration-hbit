const fs = require("fs").promises;

function formatObject(v1Obj) {
  return {
    channelPartnerId: v1Obj.channel_partner_id,
    accountId: v1Obj._id.$oid,
    holderId: "",
  };
}

function matchAccounts(arr1, arr2) {
  let matchedAccounts = [];
  for (let i = 0; i < arr1.length; i++) {
    for (let j = 0; j < arr2.length; j++) {
      if (arr1[i].accountId === arr2[j].accountId) {
        matchedAccounts.push(arr1[i]);
      }
    }
  }
  return matchedAccounts;
}

async function getHolderId(accountId) {
  const clientsHolders = await readJSONFile("holders-cp-clients.json"); //1338
  for (let i = 0; i < clientsHolders.length; i++) {
    if (clientsHolders[i].accountId === accountId) {
      return clientsHolders[i].holderId;
    }
  }
  return null;
}

async function formatObjectWithHolderId(client) {
  return {
    channelPartnerId: client.channelPartnerId,
    accountId: client.accountId,
    holderId: await getHolderId(client.accountId),
  };
}

async function readJSONFile(filePath) {
  try {
    const data = await fs.readFile(filePath, "utf8");
    return JSON.parse(data);
  } catch (err) {
    throw new Error(`Error reading JSON file: ${err}`);
  }
}

async function writeJSONFile(filePath, data) {
  try {
    const jsonData = JSON.stringify(data, null, 2);
    await fs.writeFile(filePath, jsonData, "utf8");
  } catch (err) {
    throw new Error(`Error writing JSON file: ${err}`);
  }
}

async function boot() {
  // const users = await readJSONFile("UserDeltaDatav1.json");
  // const cps = await readJSONFile("FinalChannelPartnerDataV1.json");
  // console.log("users", users.length);
  // console.log("cps", cps.length);
  // const cpsIds = cps.map((cp) => cp.id);
  // const cpClients = users.filter((user) =>
  //   user.hasOwnProperty("channel_partner_id")
  // );
  // const cpValidClients = cpClients.filter((cp) => cp.channel_partner_id !== "");
  // console.log("valid clients", cpValidClients.length);
  // const validCpIds = cpValidClients.filter((cp) =>
  //   cpsIds.includes(cp.channel_partner_id)
  // );
  // console.log(validCpIds.length, "validCpIds");
  // const validCpsV2 = validCpIds.map((cp) => formatObject(cp));
  // console.log(validCpsV2.length, "validCpIds v2");
  // writeJSONFile("cp-clients-valid-v2.json", validCpsV2);

  const cpsV2 = await readJSONFile("cp-clients-valid-v2.json");

  // const clientsHolders = await readJSONFile("holders-cp-clients.json");

  console.log(cpsV2.length); // 1645
  // console.log(clientsHolders.length);

  const finalClients = [];
  const noHolderid = [];

  for (let i = 0; i < cpsV2.length; i += 1) {
    const fc = await formatObjectWithHolderId(cpsV2[i]);
    if (fc.holderId !== null) {
      finalClients.push(fc);
    } else {
      noHolderid.push(fc);
    }
  }

  console.log({ finalclients: finalClients.length });

  writeJSONFile("FinalClientsV2.json", finalClients);
  writeJSONFile("noHolder.json", finalClients);
}

boot();
