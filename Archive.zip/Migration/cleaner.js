/*

Decided Things:
 1. `products_dealing_in` will be skipped.

*/

const fs = require("fs"); // Require the fs module

const getCountry = (cp) => {
  if (cp?.address?.country?.trim().length > 0) {
    return cp?.address?.country?.trim().toUpperCase();
  }
  return "INDIA";
};

const getState = (cp) => {
  if (cp?.address?.state?.trim().length > 0) {
    return cp?.address?.state?.trim().toUpperCase();
  }
  return "Maharastra";
};

const getCity = (cp) => {
  if (cp?.address?.city?.trim().length > 0) {
    return cp?.address?.city?.trim().toUpperCase();
  }
  return "Mumbai";
};

const getV2CpFormat = (cp, i) => {
  return {
    id: cp._id.$oid,
    firstName: cp?.first_name,
    lastName: cp?.last_name,
    companyName: cp?.company_name,
    mobileNumber: cp?.primary_phone_number?.slice(
      3,
      cp?.primary_phone_number?.length
    ),
    mobileCountryCode: cp?.primary_phone_number?.slice(0, 3),
    emailAddress: cp?.primary_email,
    country: getCountry(cp),
    state: getState(cp),
    city: getCity(cp),
    registrationNumber: cp?.registration_number,
    pincode: cp?.address?.pincode,
    KycNotStarted: "KycNotStarted",
    fullAddress: !!cp?.address
      ? `${!!cp?.address?.street ? cp?.address?.street : ""} ${
          cp?.address?.city ? cp?.address?.city : ""
        } ${cp?.address?.state ? cp?.address?.state : ""} ${
          cp?.address?.country ? cp?.address?.country : ""
        }`
      : "",
    childIds: [],
    parentId: null,
    parentName: null,
    channelPartnerOrganizationId: null,
    partnerUniqueId: i + 1,
  };
};

async function readJSONFile(filePath) {
  try {
    const data = await fs.promises.readFile(filePath, "utf8"); // Read the file
    return JSON.parse(data); // Parse the JSON string and return the object
  } catch (err) {
    console.error(err); // If there is an error, print it
  }
}

async function writeToJSONFile(obj, filePath) {
  try {
    console.log(`Writing ${obj.length} entries`);
    await fs.promises.writeFile(filePath, JSON.stringify(obj, null, 2), "utf8");
    console.log("Data written to file");
  } catch (err) {
    console.error(err);
  }
}

async function boot() {
  const v1Cps = await readJSONFile("ChannelPartnerUpdatedData.json");
  const migratedCPs = await readJSONFile("finalV2.json");

  const v2CpModel = v1Cps.map((cp) => getV2CpFormat(cp));
  // const migratedCPs =

  // const allCps = await readJSONFile("cp-v2.json");
  const migratedCPsIds = migratedCPs.map((cp) => cp.id);

  let newCps = [];

  for (let i = 0; i <= v2CpModel.length; i += 1) {
    for (let j = 0; j <= migratedCPs.length; j += 1) {
      console.log(i, j);
      if (
        v2CpModel[i] &&
        migratedCPs[j] &&
        v2CpModel[i]?.id === migratedCPs[j]?.id
      ) {
        newCps.push({
          ...migratedCPs[j],
          country: v2CpModel[i].country,
          state: v2CpModel[i].state,
          city: v2CpModel[i].city,
        });
      }
    }
  }

  for (let i = 0; i < v2CpModel.length; i += 1) {
    if (!migratedCPsIds.includes(v2CpModel[i].id)) {
      newCps.push(v2CpModel[i]);
    }
  }

  console.log(newCps.length);

  writeToJSONFile(newCps, "v2-delta.json");
}

boot();
