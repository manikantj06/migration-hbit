const fs = require("fs"); // Require the fs module

function getCleanMobileNumber(mobileNumber) {
  if (mobileNumber) {
    mobileNumber = mobileNumber.toString();
    return mobileNumber.slice(2, mobileNumber.length);
  }
  return mobileNumber;
}

function getCleanMobileCountryCode(mobileNumber) {
  if (mobileNumber) {
    mobileNumber = mobileNumber.toString();
    return `+${mobileNumber.slice(0, 2)}`;
  }

  return mobileNumber;
}

function getV2CollateralFormat(obj) {
  console.log(obj);
  const newObj = {
    id: obj._id.$oid,
    companyLogo: null,
    peopleNames: [obj.first_contact_name, obj.second_contact_name],
    peopleMobileNumbers: [
      getCleanMobileNumber(obj.first_contact_phone_number),
      getCleanMobileNumber(obj.second_contact_phone_number),
    ],
    channelPartnerOrganizationId: obj.channel_partner_id,
    companyName: null,
    peopleMobileCountryCodes: [
      getCleanMobileCountryCode(obj.first_contact_phone_number),
      getCleanMobileCountryCode(obj.second_contact_phone_number),
    ],
  };
  return newObj;
}

async function readJSONFile(filePath) {
  try {
    const data = await fs.promises.readFile(filePath, "utf8"); // Read the file
    return JSON.parse(data); // Parse the JSON string and return the object
  } catch (err) {
    console.error(err); // If there is an error, print it
  }
}

async function writeToJSONFile(obj, filePath) {
  try {
    console.log(`Writing ${obj.length} entries`);
    await fs.promises.writeFile(filePath, JSON.stringify(obj, null, 2), "utf8");
    console.log("Data written to file");
  } catch (err) {
    console.error(err);
  }
}

async function boot() {
  const allCollaterals = await readJSONFile("Collateral_V1_data.json");

  let v2Collaterals = allCollaterals.map((cp, i) =>
    getV2CollateralFormat(cp, i)
  );

  console.log(v2Collaterals);
  //   writeToJSONFile(v2Collaterals, "nri-cp-v2.json");
}

boot();
